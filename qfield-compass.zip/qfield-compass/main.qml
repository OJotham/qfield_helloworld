import QtQuick
import QtQuick.Controls
import org.qfield
Item {
id: pluginRoot
// Plugin lifecycle
Component.onCompleted: {
    // Create the compass overlay as a child of the main window
    // so it floats above the map canvas
    var overlay = Qt.createComponent("CompassOverlay.qml")
    if (overlay.status === Component.Ready) {
        var compass = overlay.createObject(iface.mainWindow(), {
            "positioning": iface.positioning()
        })
        compass.visible = true
        console.log("Compass plugin loaded successfully")
    } else {
        console.error("Failed to load compass overlay:", overlay.errorString())
        iface.mainWindow().displayToast("Compass plugin failed to load")
    }
}

}