import QtQuick
import org.qfield

Item {
    id: root
    
    // === PUBLIC ===
    property real azimuth: 0
    property real pitch: 0
    property real roll: 0
    property bool active: true
    property bool available: true
    property real calibrationLevel: 1.0
    property string mode: "auto"   // "auto", "magnetometer", "gps"
    
    // Internal
    property bool _magAvailable: false
    property bool _gpsAvailable: false
    property bool _usingMagnetometer: false
    property real _gpsBearing: 0
    property real _magBearing: 0
    
    // === POSITIONING (GPS) — Always works in QField ===
    property var _positioning: iface.positioning()
    
    Connections {
        target: _positioning
        function onPositionChanged() {
            var pos = _positioning.position
            if (pos && pos.speed > 0.3 && !isNaN(pos.direction)) {
                _gpsBearing = pos.direction
                _gpsAvailable = true
                if (mode === "auto" || mode === "gps") {
                    _usingMagnetometer = false
                    root.azimuth = _gpsBearing
                }
            }
        }
    }
    
    // === MAGNETOMETER (Mobile only) ===
    // Try to load QtSensors dynamically — won't crash if missing
    property var _magnetometer: null
    property var _accelerometer: null
    
    Component.onCompleted: {
        _initMagnetometer()
    }
    
    function _initMagnetometer() {
        try {
            // Dynamic import check
            var sensors = Qt.createQmlObject(
                'import QtSensors; Item {}',
                root,
                "sensorCheck"
            )
            
            if (!sensors) {
                console.log("QtSensors not available")
                return
            }
            
            // Create magnetometer
            _magnetometer = Qt.createQmlObject(
                'import QtSensors; Magnetometer { id: mag; active: false; dataRate: 25; ' +
                'onReadingChanged: parent._processMag(); ' +
                'onActiveChanged: console.log("Mag active:", active) }',
                root,
                "magnetometer"
            )
            
            // Create accelerometer
            _accelerometer = Qt.createQmlObject(
                'import QtSensors; Accelerometer { id: acc; active: false; dataRate: 25; ' +
                'onReadingChanged: parent._processMag(); ' +
                'onActiveChanged: console.log("Acc active:", active) }',
                root,
                "accelerometer"
            )
            
            _magAvailable = true
            console.log("QtSensors loaded successfully")
            
            // Start after delay
            Qt.callLater(function() {
                _magnetometer.active = true
                _accelerometer.active = true
            })
            
        } catch (e) {
            console.log("QtSensors not available:", e)
            _magAvailable = false
        }
    }
    
    function _processMag() {
        if (!_magnetometer || !_accelerometer) return
        if (!_magnetometer.reading || !_accelerometer.reading) return
        
        var mag = _magnetometer.reading
        var acc = _accelerometer.reading
        
        var mx = mag.x, my = mag.y, mz = mag.z
        var ax = acc.x, ay = acc.y, az = acc.z
        
        // Normalize accelerometer
        var aNorm = Math.sqrt(ax*ax + ay*ay + az*az)
        if (aNorm < 0.001) return
        ax /= aNorm; ay /= aNorm; az /= aNorm
        
        // Tilt compensation
        var pitchRad = Math.asin(-ax)
        var rollRad = 0
        if (Math.abs(pitchRad) < 1.4) {
            rollRad = Math.asin(ay / Math.cos(pitchRad))
        }
        
        var sinPitch = Math.sin(pitchRad)
        var cosPitch = Math.cos(pitchRad)
        var sinRoll = Math.sin(rollRad)
        var cosRoll = Math.cos(rollRad)
        
        var hx = mx * cosPitch + mz * sinPitch
        var hy = mx * sinRoll * sinPitch + my * cosRoll - mz * sinRoll * cosPitch
        
        var rawAzimuth = Math.atan2(hy, hx) * (180 / Math.PI)
        rawAzimuth = -rawAzimuth
        if (rawAzimuth < 0) rawAzimuth += 360
        
        // Smooth
        _magBearing = _magBearing * 0.85 + rawAzimuth * 0.15
        
        // Handle 0/360 wrap
        if (Math.abs(_magBearing - rawAzimuth) > 180) {
            _magBearing = rawAzimuth
        }
        
        if (mode === "auto" || mode === "magnetometer") {
            _usingMagnetometer = true
            root.azimuth = _magBearing
            root.pitch = pitchRad * (180 / Math.PI)
            root.roll = rollRad * (180 / Math.PI)
            
            var fieldStrength = Math.sqrt(mx*mx + my*my + mz*mz)
            root.calibrationLevel = Math.min(1.0, fieldStrength / 50.0)
        }
    }
    
    function recalibrate() {
        console.log("Recalibrating...")
        if (_usingMagnetometer) {
            _magBearing = azimuth
        }
    }
    
    function setMode(newMode) {
        mode = newMode
        if (mode === "gps") {
            _usingMagnetometer = false
            root.azimuth = _gpsBearing
        } else if (mode === "magnetometer") {
            _usingMagnetometer = true
            root.azimuth = _magBearing
        }
    }
}