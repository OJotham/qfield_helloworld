import QtQuick
import QtSensors
Item {
id: compassSensor
// === PROPERTIES ===
property real azimuth: 0          // 0-360 degrees, 0 = North
property real pitch: 0           // Device tilt forward/back
property real roll: 0            // Device tilt left/right
property bool active: true       // Sensor on/off toggle
property bool available: false   // Hardware availability

// Calibration quality (0-1)
property real calibrationLevel: 0

// === INTERNAL ===
property real _lastAzimuth: 0
property real _smoothingFactor: 0.15  // Low-pass filter (0.1-0.3 recommended)

// Magnetometer (reads magnetic field)
Magnetometer {
    id: magnetometer
    active: compassSensor.active && compassSensor.available
    dataRate: 25  // 25 Hz updates
    
    onReadingChanged: {
        if (!accelerometer.reading) return
        calculateOrientation()
    }
}

// Accelerometer (reads gravity vector for tilt compensation)
Accelerometer {
    id: accelerometer
    active: compassSensor.active && compassSensor.available
    dataRate: 25
    
    onReadingChanged: {
        if (!magnetometer.reading) return
        calculateOrientation()
    }
}

// Check sensor availability on startup
Component.onCompleted: {
    available = Magnetometer.hasSensorSupport && Accelerometer.hasSensorSupport
    if (!available) {
        console.warn("Compass sensors not available on this device")
    }
}

// === CORE CALCULATION ===
function calculateOrientation() {
    var mag = magnetometer.reading
    var acc = accelerometer.reading
    
    if (!mag || !acc) return
    
    // Get raw sensor values
    var mx = mag.x, my = mag.y, mz = mag.z
    var ax = acc.x, ay = acc.y, az = acc.z
    
    // Normalize accelerometer (gravity vector)
    var aNorm = Math.sqrt(ax*ax + ay*ay + az*az)
    ax /= aNorm; ay /= aNorm; az /= aNorm
    
    // Tilt compensation using rotation matrix
    // Project magnetic vector onto horizontal plane
    var pitchRad = Math.asin(-ax)
    var rollRad = Math.asin(ay / Math.cos(pitchRad))
    
    // Prevent gimbal lock near vertical
    if (Math.abs(pitchRad) > 1.4) rollRad = 0
    
    var sinPitch = Math.sin(pitchRad)
    var cosPitch = Math.cos(pitchRad)
    var sinRoll = Math.sin(rollRad)
    var cosRoll = Math.cos(rollRad)
    
    // Tilt-compensated magnetic components
    var hx = mx * cosPitch + mz * sinPitch
    var hy = mx * sinRoll * sinPitch + my * cosRoll - mz * sinRoll * cosPitch
    
    // Calculate azimuth (0 = North, increases clockwise)
    var rawAzimuth = Math.atan2(hy, hx) * (180 / Math.PI)
    rawAzimuth = -rawAzimuth  // Convert to clockwise from North
    if (rawAzimuth < 0) rawAzimuth += 360
    
    // Smooth with low-pass filter to reduce jitter
    var diff = rawAzimuth - _lastAzimuth
    // Handle 0/360 wrap-around
    if (diff > 180) diff -= 360
    if (diff < -180) diff += 360
    
    azimuth = _lastAzimuth + _smoothingFactor * diff
    if (azimuth < 0) azimuth += 360
    if (azimuth >= 360) azimuth -= 360
    
    _lastAzimuth = azimuth
    
    // Store pitch/roll for UI display
    pitch = pitchRad * (180 / Math.PI)
    roll = rollRad * (180 / Math.PI)
    
    // Simple calibration heuristic based on field strength variance
    var fieldStrength = Math.sqrt(mx*mx + my*my + mz*mz)
    calibrationLevel = Math.min(1.0, fieldStrength / 50.0)
}

// Public: recalibrate (reset smoothing)
function recalibrate() {
    _lastAzimuth = azimuth
    console.log("Compass recalibrated")
}

}