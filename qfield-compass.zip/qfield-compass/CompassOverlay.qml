import QtQuick
import QtQuick.Controls
import org.qfield

Item {
    id: compassOverlay
    
    // === DYNAMIC SIZING ===
    property real baseSize: 280
    property real scaleFactor: Screen.devicePixelRatio || 1.0
    property int compassSize: Math.round(baseSize * scaleFactor)
    
    property var positioning
    property real opacityLevel: 0.75
    property bool showDegrees: true
    property bool showCalibration: true
    
    x: parent ? parent.width - compassSize - (24 * scaleFactor) : 0
    y: 24 * scaleFactor
    width: compassSize
    height: compassSize + (showDegrees ? 44 * scaleFactor : 0)
    
    onXChanged: if (parent) x = Math.max(0, Math.min(x, parent.width - width))
    onYChanged: if (parent) y = Math.max(0, Math.min(y, parent.height - height))
    
    // === SENSOR ===
    CompassSensor {
        id: sensor
        active: compassOverlay.visible
    }
    
    // === DRAG ===
    MouseArea {
        anchors.fill: parent
        drag.target: compassOverlay
        drag.minimumX: 0
        drag.minimumY: 0
        drag.maximumX: parent ? parent.width - width : 0
        drag.maximumY: parent ? parent.height - height : 0
        
        onDoubleClicked: {
            opacityLevel = (opacityLevel === 0.75) ? 0.95 : 0.75
        }
        onPressAndHold: {
            sensor.recalibrate()
            calFlash.start()
        }
    }
    
    // === COMPASS CONTAINER ===
    Rectangle {
        id: compassContainer
        width: compassSize
        height: compassSize
        radius: compassSize / 2
        color: "#1a1a1a"
        opacity: opacityLevel
        border.width: 2 * scaleFactor
        border.color: Qt.rgba(1, 1, 1, 0.3)
        
        // === ROTATING ROSE ===
        Canvas {
            id: compassRose
            anchors.centerIn: parent
            width: compassSize - 24 * scaleFactor
            height: compassSize - 24 * scaleFactor
            
            rotation: -sensor.azimuth
            onRotationChanged: requestPaint()
            
            Connections {
                target: sensor
                function onAzimuthChanged() {
                    compassRose.requestPaint()
                }
            }
            
            onPaint: {
                var ctx = getContext("2d")
                var cx = width / 2
                var cy = height / 2
                var r = Math.min(cx, cy) - 6 * scaleFactor
                
                ctx.clearRect(0, 0, width, height)
                
                // Outer ring
                ctx.beginPath()
                ctx.arc(cx, cy, r, 0, 2 * Math.PI)
                ctx.strokeStyle = "rgba(255,255,255,0.2)"
                ctx.lineWidth = 1
                ctx.stroke()
                
                // Ticks
                for (var i = 0; i < 360; i += 15) {
                    var rad = i * Math.PI / 180
                    var major = (i % 90 === 0)
                    var minor = (i % 30 === 0)
                    var tLen = major ? 14 * scaleFactor : (minor ? 10 * scaleFactor : 6 * scaleFactor)
                    
                    ctx.beginPath()
                    ctx.moveTo(cx + (r - tLen) * Math.sin(rad), cy - (r - tLen) * Math.cos(rad))
                    ctx.lineTo(cx + r * Math.sin(rad), cy - r * Math.cos(rad))
                    ctx.strokeStyle = major ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.35)"
                    ctx.lineWidth = major ? 2 : 1
                    ctx.stroke()
                }
                
                // Cardinal labels
                ctx.font = "bold " + (16 * scaleFactor) + "px sans-serif"
                ctx.textAlign = "center"
                ctx.textBaseline = "middle"
                
                var dirs = [
                    {l: "N", a: 0, c: "#ff4444"},
                    {l: "E", a: 90, c: "#ffffff"},
                    {l: "S", a: 180, c: "#ffffff"},
                    {l: "W", a: 270, c: "#ffffff"}
                ]
                
                for (var j = 0; j < 4; j++) {
                    var d = dirs[j]
                    var dr = d.a * Math.PI / 180
                    var lr = r - 28 * scaleFactor
                    ctx.fillStyle = d.c
                    ctx.fillText(d.l, cx + lr * Math.sin(dr), cy - lr * Math.cos(dr))
                }
            }
        }
        
        // === FIXED NEEDLE ===
        Canvas {
            anchors.centerIn: parent
            width: compassSize - 24 * scaleFactor
            height: compassSize - 24 * scaleFactor
            
            onPaint: {
                var ctx = getContext("2d")
                var cx = width / 2
                var cy = height / 2
                var len = Math.min(cx, cy) - 18 * scaleFactor
                
                ctx.clearRect(0, 0, width, height)
                
                // North (red)
                ctx.beginPath()
                ctx.moveTo(cx, cy - len)
                ctx.lineTo(cx - 8 * scaleFactor, cy + 6 * scaleFactor)
                ctx.lineTo(cx + 8 * scaleFactor, cy + 6 * scaleFactor)
                ctx.closePath()
                ctx.fillStyle = "#ff4444"
                ctx.fill()
                
                // South (white)
                ctx.beginPath()
                ctx.moveTo(cx, cy + len)
                ctx.lineTo(cx - 8 * scaleFactor, cy - 6 * scaleFactor)
                ctx.lineTo(cx + 8 * scaleFactor, cy - 6 * scaleFactor)
                ctx.closePath()
                ctx.fillStyle = "#dddddd"
                ctx.fill()
                
                // Center dot
                ctx.beginPath()
                ctx.arc(cx, cy, 5 * scaleFactor, 0, 2 * Math.PI)
                ctx.fillStyle = "#ffffff"
                ctx.fill()
                ctx.strokeStyle = "#333333"
                ctx.lineWidth = 1
                ctx.stroke()
            }
        }
        
        // Calibration bar
        Rectangle {
            visible: showCalibration && sensor.calibrationLevel < 0.7
            anchors.top: parent.top
            anchors.topMargin: 10 * scaleFactor
            anchors.horizontalCenter: parent.horizontalCenter
            width: 90 * scaleFactor
            height: 5 * scaleFactor
            radius: 2
            color: "#333333"
            
            Rectangle {
                width: parent.width * sensor.calibrationLevel
                height: parent.height
                radius: 2
                color: sensor.calibrationLevel > 0.5 ? "#44ff44" : "#ffaa00"
                Behavior on width { NumberAnimation { duration: 200 } }
            }
        }
        
        // Cal flash
        SequentialAnimation {
            id: calFlash
            ColorAnimation { target: compassContainer; property: "border.color"; to: "#44ff44"; duration: 150 }
            ColorAnimation { target: compassContainer; property: "border.color"; to: Qt.rgba(1,1,1,0.3); duration: 300 }
        }
    }
    
    // === DIGITAL READOUT ===
    Rectangle {
        visible: showDegrees
        anchors.top: compassContainer.bottom
        anchors.topMargin: 6 * scaleFactor
        anchors.horizontalCenter: compassContainer.horizontalCenter
        width: 100 * scaleFactor
        height: 28 * scaleFactor
        radius: 6
        color: "#1a1a1a"
        opacity: opacityLevel
        
        Text {
            anchors.centerIn: parent
            text: Math.round(sensor.azimuth).toString().padStart(3, "0") + "°"
            color: "#ffffff"
            font.pixelSize: 16 * scaleFactor
            font.bold: true
            font.family: "monospace"
        }
    }
}