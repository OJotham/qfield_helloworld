import QtQuick
import QtQuick.Controls
import QtQuick.Shapes
Item {
id: compassOverlay
// === CONFIGURATION ===
property var positioning  // Injected from main.qml
property int compassSize: 180
property real opacityLevel: 0.75  // Semitransparent default
property bool showDegrees: true
property bool showCalibration: true

// Positioning (default: top-right corner)
x: parent ? parent.width - compassSize - 20 : 0
y: 20
width: compassSize
height: compassSize + (showDegrees ? 30 : 0)

// Keep within window bounds
onXChanged: if (parent) x = Math.max(0, Math.min(x, parent.width - compassSize))
onYChanged: if (parent) y = Math.max(0, Math.min(y, parent.height - height))

// === SENSOR INSTANCE ===
CompassSensor {
    id: sensor
    active: compassOverlay.visible
}

// === DRAG BEHAVIOR ===
MouseArea {
    id: dragArea
    anchors.fill: parent
    drag.target: compassOverlay
    drag.minimumX: 0
    drag.minimumY: 0
    drag.maximumX: parent ? parent.width - compassSize : 0
    drag.maximumY: parent ? parent.height - height : 0
    
    // Double-click to toggle opacity
    onDoubleClicked: {
        opacityLevel = (opacityLevel === 0.75) ? 0.95 : 0.75
    }
    
    // Long press for recalibration
    onPressAndHold: {
        sensor.recalibrate()
        calibrationFlash.start()
    }
}

// === VISUAL ROOT ===
Rectangle {
    id: compassContainer
    anchors.fill: parent
    radius: compassSize / 2
    color: "#1a1a1a"
    opacity: opacityLevel
    border.width: 2
    border.color: Qt.rgba(1, 1, 1, 0.3)
    
    // Subtle shadow
    layer.enabled: true
    layer.effect: ShaderEffectSource {
        // Fallback for older Qt versions; use DropShadow in newer
    }
    
    // === COMPASS ROSE (rotates opposite to azimuth) ===
    Canvas {
        id: compassRose
        anchors.centerIn: parent
        width: compassSize - 20
        height: compassSize - 20
        
        // Rotate the rose so North stays pointing North
        // while the device rotates
        rotation: -sensor.azimuth
        
        onPaint: {
            var ctx = getContext("2d")
            var centerX = width / 2
            var centerY = height / 2
            var radius = Math.min(centerX, centerY) - 5
            
            ctx.clearRect(0, 0, width, height)
            
            // Draw cardinal directions
            ctx.font = "bold 14px sans-serif"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            
            var directions = [
                { label: "N", angle: 0, color: "#ff4444" },
                { label: "E", angle: 90, color: "#ffffff" },
                { label: "S", angle: 180, color: "#ffffff" },
                { label: "W", angle: 270, color: "#ffffff" }
            ]
            
            // Draw tick marks
            for (var i = 0; i < 360; i += 15) {
                var rad = i * Math.PI / 180
                var isMajor = (i % 90 === 0)
                var isMinor = (i % 30 === 0)
                var tickLen = isMajor ? 12 : (isMinor ? 8 : 5)
                var tickWidth = isMajor ? 2 : 1
                
                var x1 = centerX + (radius - tickLen) * Math.sin(rad)
                var y1 = centerY - (radius - tickLen) * Math.cos(rad)
                var x2 = centerX + radius * Math.sin(rad)
                var y2 = centerY - radius * Math.cos(rad)
                
                ctx.beginPath()
                ctx.moveTo(x1, y1)
                ctx.lineTo(x2, y2)
                ctx.strokeStyle = isMajor ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.3)"
                ctx.lineWidth = tickWidth
                ctx.stroke()
            }
            
            // Draw direction labels
            for (var j = 0; j < directions.length; j++) {
                var dir = directions[j]
                var dirRad = dir.angle * Math.PI / 180
                var labelRadius = radius - 25
                var lx = centerX + labelRadius * Math.sin(dirRad)
                var ly = centerY - labelRadius * Math.cos(dirRad)
                
                ctx.fillStyle = dir.color
                ctx.fillText(dir.label, lx, ly)
            }
        }
    }
    
    // === NEEDLE (fixed, points to North) ===
    Canvas {
        id: needle
        anchors.centerIn: parent
        width: compassSize - 20
        height: compassSize - 20
        
        onPaint: {
            var ctx = getContext("2d")
            var cx = width / 2
            var cy = height / 2
            var len = Math.min(cx, cy) - 15
            
            ctx.clearRect(0, 0, width, height)
            
            // North half (red)
            ctx.beginPath()
            ctx.moveTo(cx, cy - len)
            ctx.lineTo(cx - 6, cy + 5)
            ctx.lineTo(cx + 6, cy + 5)
            ctx.closePath()
            ctx.fillStyle = "#ff4444"
            ctx.fill()
            ctx.strokeStyle = "#ff6666"
            ctx.lineWidth = 1
            ctx.stroke()
            
            // South half (white/gray)
            ctx.beginPath()
            ctx.moveTo(cx, cy + len)
            ctx.lineTo(cx - 6, cy - 5)
            ctx.lineTo(cx + 6, cy - 5)
            ctx.closePath()
            ctx.fillStyle = "#cccccc"
            ctx.fill()
            ctx.strokeStyle = "#eeeeee"
            ctx.stroke()
            
            // Center pivot
            ctx.beginPath()
            ctx.arc(cx, cy, 4, 0, 2 * Math.PI)
            ctx.fillStyle = "#ffffff"
            ctx.fill()
            ctx.strokeStyle = "#333333"
            ctx.lineWidth = 1
            ctx.stroke()
        }
    }
    
    // === CALIBRATION INDICATOR ===
    Rectangle {
        id: calIndicator
        visible: showCalibration && sensor.calibrationLevel < 0.7
        anchors.top: parent.top
        anchors.topMargin: 8
        anchors.horizontalCenter: parent.horizontalCenter
        width: 80
        height: 4
        radius: 2
        color: "#333333"
        
        Rectangle {
            width: parent.width * sensor.calibrationLevel
            height: parent.height
            radius: 2
            color: sensor.calibrationLevel > 0.5 ? "#44ff44" : "#ffaa00"
            Behavior on width { NumberAnimation { duration: 200 } }
        }
    }
    
    // Calibration flash animation
    SequentialAnimation {
        id: calibrationFlash
        ColorAnimation {
            target: compassContainer
            property: "border.color"
            to: "#44ff44"
            duration: 150
        }
        ColorAnimation {
            target: compassContainer
            property: "border.color"
            to: Qt.rgba(1, 1, 1, 0.3)
            duration: 300
        }
    }
}

// === DIGITAL READOUT ===
Rectangle {
    visible: showDegrees
    anchors.top: compassContainer.bottom
    anchors.topMargin: 4
    anchors.horizontalCenter: compassContainer.horizontalCenter
    width: 80
    height: 24
    radius: 4
    color: "#1a1a1a"
    opacity: opacityLevel
    
    Text {
        anchors.centerIn: parent
        text: Math.round(sensor.azimuth).toString().padStart(3, "0") + "°"
        color: "#ffffff"
        font.pixelSize: 14
        font.bold: true
        font.family: "monospace"
    }
}

// === SETTINGS BUTTON (small gear icon) ===
Rectangle {
    anchors.bottom: compassContainer.bottom
    anchors.right: compassContainer.right
    anchors.margins: 8
    width: 20
    height: 20
    radius: 10
    color: "#333333"
    opacity: 0.6
    
    Text {
        anchors.centerIn: parent
        text: "⚙"
        color: "white"
        font.pixelSize: 10
    }
    
    MouseArea {
        anchors.fill: parent
        onClicked: settingsMenu.open()
    }
}

// === SETTINGS MENU ===
Menu {
    id: settingsMenu
    title: "Compass Settings"
    
    MenuItem {
        text: opacityLevel === 0.75 ? "Increase Opacity" : "Decrease Opacity"
        onTriggered: {
            opacityLevel = (opacityLevel === 0.75) ? 0.95 : 0.75
        }
    }
    
    MenuItem {
        text: sensor.active ? "Pause Sensor" : "Resume Sensor"
        onTriggered: sensor.active = !sensor.active
    }
    
    MenuItem {
        text: "Recalibrate"
        onTriggered: sensor.recalibrate()
    }
    
    MenuItem {
        text: showDegrees ? "Hide Degrees" : "Show Degrees"
        onTriggered: showDegrees = !showDegrees
    }
}

}