import QtQuick
import QtQuick.Controls
import QtQuick.Shapes

import org.qfield
import org.qgis
import Theme

Item {
    id: protractorPlugin
    
    // ============================================================
    // PROPERTIES
    // ============================================================
    
    // Map canvas and settings references
    property var mapCanvas: iface.mapCanvas()
    property var mapSettings: mapCanvas ? mapCanvas.mapSettings : null
    
    // Protractor state (stored in map coordinates so it sticks to the terrain)
    property var protractorCenter: null  // QgsPoint in map CRS
    property real protractorRadiusMeters: 50.0  // 50m default radius
    property real protractorRotationGrads: 0.0    // 0-400 grad rotation
    
    // UI state
    property bool protractorVisible: false
    property bool isDragging: false
    property bool isRotating: false
    property point dragStartPos
    property real rotationStartAngle
    property real rotationStartGrads
    
    // Visual settings
    property color protractorColor: "#FF6B35"
    property real opacityValue: 0.65
    
    // Grads constants
    readonly property int gradsPerCircle: 400
    readonly property real gradToDeg: 360.0 / 400.0
    readonly property real degToGrad: 400.0 / 360.0
    
    // ============================================================
    // INITIALIZATION
    // ============================================================
    
    Component.onCompleted: {
        // Add toolbar button to toggle protractor
        iface.addItemToPluginsToolbar(toggleButton)
        
        // Initialize center at current map center if available
        if (mapSettings) {
            let center = mapSettings.getCenter()
            protractorCenter = center
        }
    }
    
    // ============================================================
    // TOOLBAR BUTTON
    // ============================================================
    
    ToolButton {
        id: toggleButton
        icon.source: "qrc:/qfield/images/themes/default/protractor.svg"  // fallback if not present
        icon.color: protractorVisible ? protractorColor : Theme.mainTextColor
        text: "Protractor"
        
        // Use a custom icon if available, otherwise use text
        contentItem: Text {
            text: "📐"
            font.pixelSize: 24
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: protractorVisible ? protractorColor : Theme.mainTextColor
        }
        
        onClicked: {
            protractorVisible = !protractorVisible
            if (protractorVisible && !protractorCenter && mapSettings) {
                protractorCenter = mapSettings.getCenter()
            }
            mainWindow.displayToast(protractorVisible ? "Protractor ON" : "Protractor OFF")
        }
    }
    
    // ============================================================
    // PROTRACTOR OVERLAY
    // ============================================================
    
    // This Item is parented to the map canvas so it overlays the map
    Item {
        id: protractorOverlay
        parent: mapCanvas ? mapCanvas : protractorPlugin
        anchors.fill: parent
        visible: protractorVisible && mapSettings !== null
        opacity: opacityValue
        
        // Prevent map interaction when touching the protractor
        // (optional - remove if you want map panning to work through it)
        
        // ============================================================
        // SCREEN POSITION CALCULATION
        // ============================================================
        
        // Convert map coordinate center to screen position
        property point screenCenter: {
            if (!mapSettings || !protractorCenter) {
                return Qt.point(0, 0)
            }
            let screenPt = mapSettings.coordinateToScreen(protractorCenter)
            return Qt.point(screenPt.x, screenPt.y)
        }
        
        // Calculate screen radius based on map scale
        // mapUnitsPerPoint gives map units (meters) per screen pixel
        property real screenRadius: {
            if (!mapSettings) return 100
            // radius in meters / mapUnitsPerPoint = radius in pixels
            // But we need to handle different CRS units
            let mpp = mapSettings.mapUnitsPerPoint
            if (mpp === 0) return 100
            return protractorRadiusMeters / mpp
        }
        
        // ============================================================
        // PROTRACTOR CANVAS DRAWING
        // ============================================================
        
        Canvas {
            id: protractorCanvas
            x: protractorOverlay.screenCenter.x - width / 2
            y: protractorOverlay.screenCenter.y - height / 2
            width: protractorOverlay.screenRadius * 2 + 40  // padding
            height: protractorOverlay.screenRadius * 2 + 40
            visible: protractorOverlay.screenRadius > 20  // hide if too small
            
            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)
                
                var cx = width / 2
                var cy = height / 2
                var r = protractorOverlay.screenRadius
                
                // -- Draw outer circle --
                ctx.beginPath()
                ctx.arc(cx, cy, r, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2
                ctx.stroke()
                
                // -- Fill semitransparent --
                ctx.fillStyle = protractorColor.replace("#", "#20")  // 20 = ~12% opacity
                ctx.fill()
                
                // -- Draw inner circle (rim) --
                ctx.beginPath()
                ctx.arc(cx, cy, r - 5, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor.replace("#", "#60")
                ctx.lineWidth = 1
                ctx.stroke()
                
                // -- Draw grad ticks and labels --
                ctx.textAlign = "center"
                ctx.textBaseline = "middle"
                ctx.font = "bold 10px sans-serif"
                
                for (var g = 0; g < gradsPerCircle; g += 5) {
                    // Convert grad to radians, applying protractor rotation
                    var angleRad = (g / gradsPerCircle) * 2 * Math.PI
                    var rotationRad = (protractorRotationGrads / gradsPerCircle) * 2 * Math.PI
                    var totalAngle = angleRad + rotationRad - Math.PI / 2  // -90deg to start at top
                    
                    var isMajor = (g % 20 === 0)
                    var isHundred = (g % 100 === 0)
                    var tickLen = isHundred ? 15 : (isMajor ? 10 : 5)
                    var tickWidth = isHundred ? 2 : 1
                    
                    var tx1 = cx + (r - tickLen) * Math.cos(totalAngle)
                    var ty1 = cy + (r - tickLen) * Math.sin(totalAngle)
                    var tx2 = cx + r * Math.cos(totalAngle)
                    var ty2 = cy + r * Math.sin(totalAngle)
                    
                    ctx.beginPath()
                    ctx.moveTo(tx1, ty1)
                    ctx.lineTo(tx2, ty2)
                    ctx.strokeStyle = protractorColor
                    ctx.lineWidth = tickWidth
                    ctx.stroke()
                    
                    // Draw labels for every 20 grads
                    if (isMajor) {
                        var labelR = r - 25
                        var lx = cx + labelR * Math.cos(totalAngle)
                        var ly = cy + labelR * Math.sin(totalAngle)
                        
                        ctx.fillStyle = protractorColor
                        ctx.font = isHundred ? "bold 12px sans-serif" : "10px sans-serif"
                        ctx.fillText(g.toString(), lx, ly)
                    }
                }
                
                // -- Draw center crosshair --
                ctx.beginPath()
                ctx.moveTo(cx - 10, cy)
                ctx.lineTo(cx + 10, cy)
                ctx.moveTo(cx, cy - 10)
                ctx.lineTo(cx, cy + 10)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2
                ctx.stroke()
                
                // -- Draw center dot --
                ctx.beginPath()
                ctx.arc(cx, cy, 4, 0, 2 * Math.PI)
                ctx.fillStyle = protractorColor
                ctx.fill()
                
                // -- Draw rotation handle (at 0 grad mark) --
                var handleAngle = (protractorRotationGrads / gradsPerCircle) * 2 * Math.PI - Math.PI / 2
                var hx = cx + r * Math.cos(handleAngle)
                var hy = cy + r * Math.sin(handleAngle)
                
                ctx.beginPath()
                ctx.arc(hx, hy, 8, 0, 2 * Math.PI)
                ctx.fillStyle = "#FF0000"
                ctx.fill()
                ctx.strokeStyle = "#FFFFFF"
                ctx.lineWidth = 2
                ctx.stroke()
            }
            
            // Redraw when properties change
            onVisibleChanged: requestPaint()
            Component.onCompleted: requestPaint()
        }
        
        // Timer to trigger redraws on map changes
        Timer {
            interval: 50
            running: protractorVisible && mapSettings !== null
            repeat: true
            onTriggered: {
                protractorCanvas.requestPaint()
            }
        }
        
        // ============================================================
        // TOUCH/INTERACTION AREAS
        // ============================================================
        
        // Main drag area (center of protractor)
        MouseArea {
            id: dragArea
            x: protractorCanvas.x + protractorCanvas.width / 2 - 30
            y: protractorCanvas.y + protractorCanvas.height / 2 - 30
            width: 60
            height: 60
            enabled: protractorVisible
            
            onPressed: {
                isDragging = true
                dragStartPos = Qt.point(mouse.x, mouse.y)
            }
            
            onPositionChanged: {
                if (isDragging && mapSettings) {
                    // Calculate new screen position
                    var newScreenX = protractorOverlay.screenCenter.x + (mouse.x - dragStartPos.x)
                    var newScreenY = protractorOverlay.screenCenter.y + (mouse.y - dragStartPos.y)
                    
                    // Convert back to map coordinate
                    var newMapPoint = mapSettings.screenToCoordinate(Qt.point(newScreenX, newScreenY))
                    protractorCenter = newMapPoint
                }
            }
            
            onReleased: {
                isDragging = false
            }
            
            // Visual feedback
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: isDragging ? protractorColor : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // Rotation handle area
        MouseArea {
            id: rotateArea
            enabled: protractorVisible
            
            // Position at the rotation handle
            x: protractorCanvas.x + protractorCanvas.width / 2 + 
               protractorOverlay.screenRadius * Math.cos((protractorRotationGrads / gradsPerCircle) * 2 * Math.PI - Math.PI / 2) - 15
            y: protractorCanvas.y + protractorCanvas.height / 2 + 
               protractorOverlay.screenRadius * Math.sin((protractorRotationGrads / gradsPerCircle) * 2 * Math.PI - Math.PI / 2) - 15
            width: 30
            height: 30
            
            onPressed: {
                isRotating = true
                // Calculate angle from center to mouse
                var centerX = protractorOverlay.screenCenter.x
                var centerY = protractorOverlay.screenCenter.y
                rotationStartAngle = Math.atan2(mouse.y + rotateArea.y - centerY, 
                                                mouse.x + rotateArea.x - centerX)
                rotationStartGrads = protractorRotationGrads
            }
            
            onPositionChanged: {
                if (isRotating) {
                    var centerX = protractorOverlay.screenCenter.x
                    var centerY = protractorOverlay.screenCenter.y
                    var currentAngle = Math.atan2(mouse.y + rotateArea.y - centerY,
                                                  mouse.x + rotateArea.x - centerX)
                    var angleDiff = currentAngle - rotationStartAngle
                    
                    // Convert to grads
                    var gradDiff = (angleDiff / (2 * Math.PI)) * gradsPerCircle
                    protractorRotationGrads = (rotationStartGrads + gradDiff) % gradsPerCircle
                    if (protractorRotationGrads < 0) protractorRotationGrads += gradsPerCircle
                }
            }
            
            onReleased: {
                isRotating = false
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: isRotating ? "#FF0000" : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // CONTROLS PANEL
        // ============================================================
        
        Rectangle {
            id: controlsPanel
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
            width: 160
            height: 220
            color: Theme.mainBackgroundColor
            border.color: Theme.mainTextColor
            border.width: 1
            radius: 8
            opacity: 0.9
            visible: protractorVisible
            
            Column {
                anchors.fill: parent
                anchors.margins: 10
                spacing: 8
                
                Text {
                    text: "Protractor"
                    font.bold: true
                    color: Theme.mainTextColor
                    horizontalAlignment: Text.AlignHCenter
                    width: parent.width
                }
                
                Text {
                    text: "Radius: " + protractorRadiusMeters + " m"
                    color: Theme.mainTextColor
                    font.pixelSize: 12
                }
                
                Slider {
                    from: 10
                    to: 500
                    value: protractorRadiusMeters
                    onValueChanged: protractorRadiusMeters = value
                    width: parent.width
                }
                
                Text {
                    text: "Rotation: " + Math.round(protractorRotationGrads) + " g"
                    color: Theme.mainTextColor
                    font.pixelSize: 12
                }
                
                Slider {
                    from: 0
                    to: 400
                    value: protractorRotationGrads
                    onValueChanged: protractorRotationGrads = value
                    width: parent.width
                }
                
                Button {
                    text: "Reset Rotation"
                    width: parent.width
                    onClicked: protractorRotationGrads = 0
                }
                
                Button {
                    text: "Center on Map"
                    width: parent.width
                    onClicked: {
                        if (mapSettings) {
                            protractorCenter = mapSettings.getCenter()
                        }
                    }
                }
                
                Button {
                    text: "Snap to 10g"
                    width: parent.width
                    onClicked: {
                        protractorRotationGrads = Math.round(protractorRotationGrads / 10) * 10
                    }
                }
            }
        }
    }
    
    // ============================================================
    // MAP CANVAS POINT HANDLER (for tap-to-place)
    // ============================================================
    
    // Alternative: use MapCanvasPointHandler for tap integration
    // This requires QField 3.6+
    
    Component {
        id: pointHandlerComponent
        MapCanvasPointHandler {
            onClicked: {
                if (protractorVisible && !isDragging && !isRotating) {
                    // Place protractor at tap location
                    protractorCenter = mapSettings.screenToCoordinate(point.position)
                    mainWindow.displayToast("Protractor placed")
                }
            }
        }
    }
}