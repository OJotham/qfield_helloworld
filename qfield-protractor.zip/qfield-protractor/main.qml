import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield
import org.qgis
import Theme

Item {
    id: pluginRoot
    
    // ============================================================
    // CORE REFERENCES
    // ============================================================
    
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var mapSettings: mapCanvas ? mapCanvas.mapSettings : null
    
    // ============================================================
    // PROTRACTOR STATE
    // ============================================================
    
    // Center in map coordinates (stored as a simple JS object with x,y)
    property var protractorCenter: null
    property real protractorRadiusMeters: 50.0
    property real protractorRotationGrads: 0.0
    property bool protractorActive: false
    
    // Visuals
    property color protractorColor: "#FF6B35"
    property real protractorOpacity: 0.65
    
    // Constants
    readonly property int gradsFullCircle: 400
    readonly property real gradToRad: 2.0 * Math.PI / 400.0
    
    // ============================================================
    // INITIALIZATION
    // ============================================================
    
    Component.onCompleted: {
        // Add button to the plugins toolbar
        iface.addItemToPluginsToolbar(toggleButton)
        
        // Initialize center to current map center
        if (mapSettings) {
            let center = mapSettings.center
            protractorCenter = { x: center.x, y: center.y }
        }
    }
    
    // ============================================================
    // TOOLBAR BUTTON
    // ============================================================
    
    ToolButton {
        id: toggleButton
        icon.source: "qrc:/qfield/images/themes/default/protractor.svg"
        icon.color: protractorActive ? protractorColor : Theme.mainTextColor
        
        // Fallback if icon not found
        contentItem: Text {
            text: "📐"
            font.pixelSize: 20
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: protractorActive ? protractorColor : Theme.mainTextColor
        }
        
        onClicked: {
            protractorActive = !protractorActive
            if (protractorActive && !protractorCenter && mapSettings) {
                let c = mapSettings.center
                protractorCenter = { x: c.x, y: c.y }
            }
            mainWindow.displayToast(protractorActive ? "Protractor ON" : "Protractor OFF")
        }
    }
    
    // ============================================================
    // OVERLAY - This is the KEY part
    // Must be a child of pluginRoot, NOT reparented to mapCanvas
    // ============================================================
    
    Rectangle {
        id: overlayContainer
        anchors.fill: parent
        color: "transparent"
        visible: protractorActive && mapSettings !== null
        opacity: protractorOpacity
        
        // Block touches on the overlay from passing through to the map
        // (Optional: remove this if you want to interact with map through protractor)
        
        // ============================================================
        // SCREEN POSITION CONVERSION
        // ============================================================
        
        // Convert map center to screen pixels
        property point screenCenter: {
            if (!mapSettings || !protractorCenter) {
                return Qt.point(-9999, -9999)  // Off-screen if invalid
            }
            let pt = mapSettings.coordinateToScreen(
                Qt.point(protractorCenter.x, protractorCenter.y)
            )
            return Qt.point(pt.x, pt.y)
        }
        
        // Calculate screen radius in pixels
        property real screenRadius: {
            if (!mapSettings || mapSettings.mapUnitsPerPoint <= 0) return 100
            return protractorRadiusMeters / mapSettings.mapUnitsPerPoint
        }
        
        // ============================================================
        // PROTRACTOR CANVAS
        // ============================================================
        
        Canvas {
            id: protractorCanvas
            x: overlayContainer.screenCenter.x - width / 2
            y: overlayContainer.screenCenter.y - height / 2
            width: Math.max(overlayContainer.screenRadius * 2 + 60, 0)
            height: width
            visible: overlayContainer.screenCenter.x > -1000 && overlayContainer.screenRadius > 10
            
            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)
                
                var cx = width / 2
                var cy = height / 2
                var r = overlayContainer.screenRadius
                
                if (r <= 0) return
                
                // -- Outer circle --
                ctx.beginPath()
                ctx.arc(cx, cy, r, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2.5
                ctx.stroke()
                
                // -- Semitransparent fill --
                ctx.fillStyle = protractorColor.replace("#", "#22")  // ~13% opacity
                ctx.fill()
                
                // -- Inner rim --
                ctx.beginPath()
                ctx.arc(cx, cy, r - 4, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor.replace("#", "#55")
                ctx.lineWidth = 1
                ctx.stroke()
                
                // -- Graduation marks --
                ctx.textAlign = "center"
                ctx.textBaseline = "middle"
                ctx.font = "bold 10px sans-serif"
                
                for (var g = 0; g < 400; g += 5) {
                    var angleRad = (g * gradToRad) + (protractorRotationGrads * gradToRad) - Math.PI / 2
                    
                    var isMajor = (g % 20 === 0)
                    var isHundred = (g % 100 === 0)
                    var tickLen = isHundred ? 14 : (isMajor ? 9 : 5)
                    
                    var tx1 = cx + (r - tickLen) * Math.cos(angleRad)
                    var ty1 = cy + (r - tickLen) * Math.sin(angleRad)
                    var tx2 = cx + r * Math.cos(angleRad)
                    var ty2 = cy + r * Math.sin(angleRad)
                    
                    ctx.beginPath()
                    ctx.moveTo(tx1, ty1)
                    ctx.lineTo(tx2, ty2)
                    ctx.strokeStyle = protractorColor
                    ctx.lineWidth = isHundred ? 2 : 1
                    ctx.stroke()
                    
                    // Labels every 20 grads
                    if (isMajor) {
                        var labelR = r - 22
                        var lx = cx + labelR * Math.cos(angleRad)
                        var ly = cy + labelR * Math.sin(angleRad)
                        ctx.fillStyle = protractorColor
                        ctx.font = isHundred ? "bold 12px sans-serif" : "10px sans-serif"
                        ctx.fillText(g.toString(), lx, ly)
                    }
                }
                
                // -- Center crosshair --
                ctx.beginPath()
                ctx.moveTo(cx - 8, cy)
                ctx.lineTo(cx + 8, cy)
                ctx.moveTo(cx, cy - 8)
                ctx.lineTo(cx, cy + 8)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2
                ctx.stroke()
                
                // -- Center dot --
                ctx.beginPath()
                ctx.arc(cx, cy, 3, 0, 2 * Math.PI)
                ctx.fillStyle = protractorColor
                ctx.fill()
                
                // -- Rotation handle at 0 grad (top) --
                var handleAngle = (protractorRotationGrads * gradToRad) - Math.PI / 2
                var hx = cx + r * Math.cos(handleAngle)
                var hy = cy + r * Math.sin(handleAngle)
                
                ctx.beginPath()
                ctx.arc(hx, hy, 7, 0, 2 * Math.PI)
                ctx.fillStyle = "#FF3333"
                ctx.fill()
                ctx.strokeStyle = "#FFFFFF"
                ctx.lineWidth = 2
                ctx.stroke()
            }
        }
        
        // Force redraw on map changes
        Timer {
            interval: 100
            running: protractorActive && mapSettings !== null
            repeat: true
            onTriggered: protractorCanvas.requestPaint()
        }
        
        // ============================================================
        // DRAG AREA (center of protractor)
        // ============================================================
        
        MouseArea {
            id: dragArea
            x: overlayContainer.screenCenter.x - 25
            y: overlayContainer.screenCenter.y - 25
            width: 50
            height: 50
            enabled: protractorActive
            
            onPressed: {
                dragArea.dragStartX = mouse.x
                dragArea.dragStartY = mouse.y
            }
            
            onPositionChanged: {
                if (pressed && mapSettings) {
                    var dx = mouse.x - dragArea.dragStartX
                    var dy = mouse.y - dragArea.dragStartY
                    
                    var newScreenX = overlayContainer.screenCenter.x + dx
                    var newScreenY = overlayContainer.screenCenter.y + dy
                    
                    var newMapPt = mapSettings.screenToCoordinate(
                        Qt.point(newScreenX, newScreenY)
                    )
                    protractorCenter = { x: newMapPt.x, y: newMapPt.y }
                }
            }
            
            // Visual feedback
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? protractorColor : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // ROTATION HANDLE AREA
        // ============================================================
        
        MouseArea {
            id: rotateArea
            enabled: protractorActive
            
            property real handleX: {
                if (!mapSettings) return 0
                var angle = (protractorRotationGrads * gradToRad) - Math.PI / 2
                return overlayContainer.screenCenter.x + overlayContainer.screenRadius * Math.cos(angle) - 12
            }
            property real handleY: {
                if (!mapSettings) return 0
                var angle = (protractorRotationGrads * gradToRad) - Math.PI / 2
                return overlayContainer.screenCenter.y + overlayContainer.screenRadius * Math.sin(angle) - 12
            }
            
            x: handleX
            y: handleY
            width: 24
            height: 24
            
            onPressed: {
                rotateArea.startAngle = Math.atan2(
                    mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                    mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                )
                rotateArea.startGrads = protractorRotationGrads
            }
            
            onPositionChanged: {
                if (pressed) {
                    var currentAngle = Math.atan2(
                        mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                        mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                    )
                    var angleDiff = currentAngle - rotateArea.startAngle
                    var gradDiff = (angleDiff / (2 * Math.PI)) * 400
                    protractorRotationGrads = (rotateArea.startGrads + gradDiff) % 400
                    if (protractorRotationGrads < 0) protractorRotationGrads += 400
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? "#FF3333" : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // SETTINGS PANEL
        // ============================================================
        
        Rectangle {
            id: settingsPanel
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
            width: 150
            height: 200
            color: Theme.mainBackgroundColor
            border.color: Theme.mainTextColor
            border.width: 1
            radius: 6
            opacity: 0.95
            visible: protractorActive
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 6
                
                Label {
                    text: "Protractor"
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }
                
                Label {
                    text: "Radius: " + Math.round(protractorRadiusMeters) + " m"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 10
                    to: 500
                    value: protractorRadiusMeters
                    onValueChanged: protractorRadiusMeters = value
                    Layout.fillWidth: true
                }
                
                Label {
                    text: "Rotation: " + Math.round(protractorRotationGrads) + " g"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 0
                    to: 400
                    value: protractorRotationGrads
                    onValueChanged: protractorRotationGrads = value
                    Layout.fillWidth: true
                }
                
                Button {
                    text: "Reset"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = 0
                        if (mapSettings) {
                            let c = mapSettings.center
                            protractorCenter = { x: c.x, y: c.y }
                        }
                    }
                }
                
                Button {
                    text: "Snap to 10g"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = Math.round(protractorRotationGrads / 10) * 10
                    }
                }
            }
        }
    }
}