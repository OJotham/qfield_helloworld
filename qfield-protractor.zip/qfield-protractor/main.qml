import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield
import org.qgis
import Theme

Item {
    id: pluginRoot
    
    // ============================================================
    // CORE REFERENCES
    // ============================================================
    
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var mapSettings: mapCanvas ? mapCanvas.mapSettings : null
    
    // ============================================================
    // PROTRACTOR STATE
    // ============================================================
    
    property var protractorCenter: null
    property real protractorRadiusMeters: 200.0
    property real protractorRotationGrads: 0.0
    property bool protractorActive: false
    
    property color protractorColor: "#FF6B35"
    property real protractorOpacity: 0.65
    
    readonly property int gradsFullCircle: 400
    readonly property real gradToRad: 2.0 * Math.PI / 400.0
    
    // ============================================================
    // INITIALIZATION
    // ============================================================
    
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(toggleButton)
        
        if (mapSettings) {
            let c = mapSettings.getCenter()
            protractorCenter = { x: c.x, y: c.y }
        }
    }
    
    // ============================================================
    // TOOLBAR BUTTON
    // ============================================================
    
    ToolButton {
        id: toggleButton
        contentItem: Text {
            text: "📐"
            font.pixelSize: 20
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: protractorActive ? protractorColor : Theme.mainTextColor
        }
        
        onClicked: {
            protractorActive = !protractorActive
            if (protractorActive && !protractorCenter && mapSettings) {
                let c = mapSettings.getCenter()
                protractorCenter = { x: c.x, y: c.y }
            }
            mainWindow.displayToast(protractorActive ? "Protractor ON" : "Protractor OFF")
        }
    }
    
    // ============================================================
    // OVERLAY - Must fill the plugin root, not mapCanvas
    // ============================================================
    
    Rectangle {
        id: overlayContainer
        anchors.fill: parent
        color: "transparent"
        visible: protractorActive && mapSettings !== null
        opacity: protractorOpacity
        
        // ============================================================
        // SCREEN POSITION & RADIUS
        // ============================================================
        
        property point screenCenter: {
            if (!mapSettings || !protractorCenter) {
                return Qt.point(-9999, -9999)
            }
            let pt = mapSettings.coordinateToScreen(
                Qt.point(protractorCenter.x, protractorCenter.y)
            )
            return Qt.point(pt.x, pt.y)
        }
        
        // Use mapSettings.devicePixelRatio for correct scaling
        property real dpr: mapSettings ? mapSettings.devicePixelRatio : 1.0
        
        // Calculate screen radius using the proper scale formula
        // scale = (distance on ground) / (distance on screen)
        // screen pixels = (ground distance in meters) * (dpi / 0.0254) / scale
        property real screenRadius: {
            if (!mapSettings) return 100
            
            let scale = mapSettings.scale
            let dpi = mapSettings.outputDpi
            
            if (scale <= 0 || dpi <= 0) return 100
            
            // Convert meters to pixels: pixels = meters * (dpi / 0.0254) / scale
            let pixelsPerMeter = dpi / 0.0254 / scale
            return protractorRadiusMeters * pixelsPerMeter
        }
        
        // ============================================================
        // PROTRACTOR CANVAS - FIXED HIGH-DPI HANDLING
        // ============================================================
        
        // The canvas logical size (what QML sees for layout)
        property real canvasLogicalSize: Math.max(screenRadius * 2 + 80, 100)
        
        Canvas {
            id: protractorCanvas
            x: overlayContainer.screenCenter.x - width / 2
            y: overlayContainer.screenCenter.y - height / 2
            width: overlayContainer.canvasLogicalSize
            height: overlayContainer.canvasLogicalSize
            
            // CRITICAL FIX: Set the actual pixel buffer size using canvasSize
            // This is separate from the width/height layout properties!
            canvasSize.width: width * overlayContainer.dpr
            canvasSize.height: height * overlayContainer.dpr
            
            antialiasing: true
            renderTarget: Canvas.FramebufferObject
            
            visible: overlayContainer.screenCenter.x > -1000 && overlayContainer.screenRadius > 5
            
            onPaint: {
                var ctx = getContext("2d")
                
                // CRITICAL FIX: Scale the context by DPR so all drawing uses logical coords
                // but renders at full physical resolution
                ctx.resetTransform()
                ctx.scale(overlayContainer.dpr, overlayContainer.dpr)
                
                // Clear using logical dimensions
                ctx.clearRect(0, 0, width, height)
                
                var cx = width / 2
                var cy = height / 2
                var r = overlayContainer.screenRadius
                
                if (r <= 0 || r > width / 2) return
                
                // -- Outer circle --
                ctx.beginPath()
                ctx.arc(cx, cy, r, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2.5
                ctx.stroke()
                
                // -- Semitransparent fill --
                ctx.fillStyle = protractorColor.replace("#", "#22")
                ctx.fill()
                
                // -- Inner rim --
                ctx.beginPath()
                ctx.arc(cx, cy, r - 4, 0, 2 * Math.PI)
                ctx.strokeStyle = protractorColor.replace("#", "#55")
                ctx.lineWidth = 1
                ctx.stroke()
                
                // -- Graduation marks --
                ctx.textAlign = "center"
                ctx.textBaseline = "middle"
                
                for (var g = 0; g < 400; g += 5) {
                    var angleRad = (g * gradToRad) + (protractorRotationGrads * gradToRad) - Math.PI / 2
                    
                    var isMajor = (g % 20 === 0)
                    var isHundred = (g % 100 === 0)
                    var tickLen = isHundred ? 14 : (isMajor ? 9 : 5)
                    
                    var tx1 = cx + (r - tickLen) * Math.cos(angleRad)
                    var ty1 = cy + (r - tickLen) * Math.sin(angleRad)
                    var tx2 = cx + r * Math.cos(angleRad)
                    var ty2 = cy + r * Math.sin(angleRad)
                    
                    ctx.beginPath()
                    ctx.moveTo(tx1, ty1)
                    ctx.lineTo(tx2, ty2)
                    ctx.strokeStyle = protractorColor
                    ctx.lineWidth = isHundred ? 2 : 1
                    ctx.stroke()
                    
                    // Labels every 20 grads
                    if (isMajor) {
                        var labelR = r - 22
                        var lx = cx + labelR * Math.cos(angleRad)
                        var ly = cy + labelR * Math.sin(angleRad)
                        ctx.fillStyle = protractorColor
                        ctx.font = isHundred ? "bold 12px sans-serif" : "10px sans-serif"
                        ctx.fillText(g.toString(), lx, ly)
                    }
                }
                
                // -- Center crosshair --
                ctx.beginPath()
                ctx.moveTo(cx - 8, cy)
                ctx.lineTo(cx + 8, cy)
                ctx.moveTo(cx, cy - 8)
                ctx.lineTo(cx, cy + 8)
                ctx.strokeStyle = protractorColor
                ctx.lineWidth = 2
                ctx.stroke()
                
                // -- Center dot --
                ctx.beginPath()
                ctx.arc(cx, cy, 3, 0, 2 * Math.PI)
                ctx.fillStyle = protractorColor
                ctx.fill()
                
                // -- Rotation handle at 0 grad (top) --
                var handleAngle = (protractorRotationGrads * gradToRad) - Math.PI / 2
                var hx = cx + r * Math.cos(handleAngle)
                var hy = cy + r * Math.sin(handleAngle)
                
                ctx.beginPath()
                ctx.arc(hx, hy, 7, 0, 2 * Math.PI)
                ctx.fillStyle = "#FF3333"
                ctx.fill()
                ctx.strokeStyle = "#FFFFFF"
                ctx.lineWidth = 2
                ctx.stroke()
            }
        }
        
        // Redraw timer
        Timer {
            interval: 100
            running: protractorActive && mapSettings !== null
            repeat: true
            onTriggered: protractorCanvas.requestPaint()
        }
        
        // ============================================================
        // DRAG AREA (center of protractor)
        // ============================================================
        
        MouseArea {
            id: dragArea
            x: overlayContainer.screenCenter.x - 25
            y: overlayContainer.screenCenter.y - 25
            width: 50
            height: 50
            enabled: protractorActive
            
            property real dragStartX: 0
            property real dragStartY: 0
            
            onPressed: {
                dragStartX = mouse.x
                dragStartY = mouse.y
            }
            
            onPositionChanged: {
                if (pressed && mapSettings) {
                    var dx = mouse.x - dragStartX
                    var dy = mouse.y - dragStartY
                    
                    var newScreenX = overlayContainer.screenCenter.x + dx
                    var newScreenY = overlayContainer.screenCenter.y + dy
                    
                    var newMapPt = mapSettings.screenToCoordinate(
                        Qt.point(newScreenX, newScreenY)
                    )
                    protractorCenter = { x: newMapPt.x, y: newMapPt.y }
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? protractorColor : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // ROTATION HANDLE
        // ============================================================
        
        MouseArea {
            id: rotateArea
            enabled: protractorActive
            
            property real handleAngle: (protractorRotationGrads * gradToRad) - Math.PI / 2
            property real handleX: overlayContainer.screenCenter.x + overlayContainer.screenRadius * Math.cos(handleAngle) - 12
            property real handleY: overlayContainer.screenCenter.y + overlayContainer.screenRadius * Math.sin(handleAngle) - 12
            
            x: handleX
            y: handleY
            width: 24
            height: 24
            
            property real startAngle: 0
            property real startGrads: 0
            
            onPressed: {
                startAngle = Math.atan2(
                    mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                    mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                )
                startGrads = protractorRotationGrads
            }
            
            onPositionChanged: {
                if (pressed) {
                    var currentAngle = Math.atan2(
                        mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                        mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                    )
                    var angleDiff = currentAngle - startAngle
                    var gradDiff = (angleDiff / (2 * Math.PI)) * 400
                    protractorRotationGrads = (startGrads + gradDiff) % 400
                    if (protractorRotationGrads < 0) protractorRotationGrads += 400
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? "#FF3333" : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // SETTINGS PANEL
        // ============================================================
        
        Rectangle {
            id: settingsPanel
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
            width: 150
            height: 200
            color: Theme.mainBackgroundColor
            border.color: Theme.mainTextColor
            border.width: 1
            radius: 6
            opacity: 0.95
            visible: protractorActive
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 6
                
                Label {
                    text: "Protractor"
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }
                
                Label {
                    text: "Radius: " + Math.round(protractorRadiusMeters) + " m"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 10
                    to: 500
                    value: protractorRadiusMeters
                    onValueChanged: protractorRadiusMeters = value
                    Layout.fillWidth: true
                }
                
                Label {
                    text: "Rotation: " + Math.round(protractorRotationGrads) + " g"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 0
                    to: 400
                    value: protractorRotationGrads
                    onValueChanged: protractorRotationGrads = value
                    Layout.fillWidth: true
                }
                
                Button {
                    text: "Reset"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = 0
                        if (mapSettings) {
                            let c = mapSettings.getCenter()
                            protractorCenter = { x: c.x, y: c.y }
                        }
                    }
                }
                
                Button {
                    text: "Snap to 10g"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = Math.round(protractorRotationGrads / 10) * 10
                    }
                }
            }
        }
    }
}