import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Shapes

import org.qfield
import org.qgis
import Theme

Item {
    id: pluginRoot
    
    // ============================================================
    // CORE REFERENCES
    // ============================================================
    
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var mapSettings: mapCanvas ? mapCanvas.mapSettings : null
    
    // ============================================================
    // PROTRACTOR STATE
    // ============================================================
    
    property var protractorCenter: null
    property real protractorRadiusMeters: 50.0
    property real protractorRotationGrads: 0.0
    property bool protractorActive: false
    
    property color protractorColor: "#FF6B35"
    property real protractorOpacity: 0.65
    
    readonly property int gradsFullCircle: 400
    readonly property real gradToRad: 2.0 * Math.PI / 400.0
    
    // ============================================================
    // INITIALIZATION
    // ============================================================
    
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(toggleButton)
        
        if (mapSettings) {
            let c = mapSettings.getCenter()
            protractorCenter = { x: c.x, y: c.y }
        }
    }
    
    // ============================================================
    // TOOLBAR BUTTON
    // ============================================================
    
    ToolButton {
        id: toggleButton
        contentItem: Text {
            text: "📐"
            font.pixelSize: 20
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: protractorActive ? protractorColor : Theme.mainTextColor
        }
        
        onClicked: {
            protractorActive = !protractorActive
            if (protractorActive && !protractorCenter && mapSettings) {
                let c = mapSettings.getCenter()
                protractorCenter = { x: c.x, y: c.y }
            }
            mainWindow.displayToast(protractorActive ? "Protractor ON" : "Protractor OFF")
        }
    }
    
    // ============================================================
    // OVERLAY CONTAINER
    // ============================================================
    
    Rectangle {
        id: overlayContainer
        anchors.fill: parent
        color: "transparent"
        visible: protractorActive && mapSettings !== null
        opacity: protractorOpacity
        
        // ============================================================
        // SCREEN POSITION & RADIUS
        // ============================================================
        
        property point screenCenter: {
            if (!mapSettings || !protractorCenter) {
                return Qt.point(-9999, -9999)
            }
            let pt = mapSettings.coordinateToScreen(
                Qt.point(protractorCenter.x, protractorCenter.y)
            )
            return Qt.point(pt.x, pt.y)
        }
        
        // RELIABLE radius calculation:
        // mapUnitsPerPoint = map CRS units per screen pixel
        // For projected CRS in meters: this IS meters per pixel
        // For geographic CRS (degrees): we detect and convert
        property real screenRadius: {
            if (!mapSettings || !protractorCenter) return 100
            
            let mpp = mapSettings.mapUnitsPerPoint
            if (mpp <= 0 || !isFinite(mpp)) return 100
            
            // Check if CRS is geographic (degrees)
            let centerPt = mapSettings.center
            let isGeographic = Math.abs(centerPt.x) <= 180 && Math.abs(centerPt.y) <= 90
            
            let metersPerPixel
            
            if (isGeographic) {
                // Geographic CRS: mpp is in degrees
                // 1 degree latitude ≈ 111,320 meters
                // Adjust for latitude: cos(lat) for longitude
                let latRad = centerPt.y * Math.PI / 180
                let metersPerDegree = 111320 * Math.cos(latRad)
                metersPerPixel = mpp * metersPerDegree
            } else {
                // Projected CRS: check units
                let crs = mapSettings.destinationCrs
                let mapUnits = crs ? crs.mapUnits : 1  // 1=meters
                
                if (mapUnits === 2) {
                    // Feet
                    metersPerPixel = mpp * 0.3048
                } else if (mapUnits === 3) {
                    // Degrees (shouldn't happen if isGeographic caught it, but fallback)
                    metersPerPixel = mpp * 111320
                } else {
                    // Meters or unknown - assume meters
                    metersPerPixel = mpp
                }
            }
            
            if (metersPerPixel <= 0 || !isFinite(metersPerPixel)) return 100
            
            // pixels = meters / (meters per pixel)
            let radiusPx = protractorRadiusMeters / metersPerPixel
            
            // Clamp to reasonable range
            return Math.max(20, Math.min(radiusPx, 2000))
        }
        
        // ============================================================
        // PROTRACTOR USING Shape (vector, no Canvas clipping issues)
        // ============================================================
        
        Item {
            id: protractorItem
            x: overlayContainer.screenCenter.x - size / 2
            y: overlayContainer.screenCenter.y - size / 2
            width: size
            height: size
            
            property real size: Math.max(overlayContainer.screenRadius * 2 + 100, 100)
            property real radius: overlayContainer.screenRadius
            property real cx: size / 2
            property real cy: size / 2
            
            visible: overlayContainer.screenCenter.x > -1000 && overlayContainer.screenRadius > 10
            
            // Outer circle
            Shape {
                anchors.fill: parent
                vendorExtensionsEnabled: true
                
                ShapePath {
                    strokeColor: protractorColor
                    strokeWidth: 2.5
                    fillColor: protractorColor.replace("#", "#22")
                    capStyle: ShapePath.RoundCap
                    joinStyle: ShapePath.RoundJoin
                    
                    PathAngleArc {
                        centerX: protractorItem.cx
                        centerY: protractorItem.cy
                        radiusX: protractorItem.radius
                        radiusY: protractorItem.radius
                        startAngle: 0
                        sweepAngle: 360
                    }
                }
            }
            
            // Inner rim
            Shape {
                anchors.fill: parent
                vendorExtensionsEnabled: true
                
                ShapePath {
                    strokeColor: protractorColor.replace("#", "#55")
                    strokeWidth: 1
                    fillColor: "transparent"
                    
                    PathAngleArc {
                        centerX: protractorItem.cx
                        centerY: protractorItem.cy
                        radiusX: protractorItem.radius - 4
                        radiusY: protractorItem.radius - 4
                        startAngle: 0
                        sweepAngle: 360
                    }
                }
            }
            
            // Graduation marks (every 5 grads)
            Repeater {
                model: 80  // 400 / 5 = 80 ticks
                
                Shape {
                    anchors.fill: parent
                    vendorExtensionsEnabled: true
                    
                    property int gradValue: index * 5
                    property real angleRad: (gradValue * gradToRad) + (protractorRotationGrads * gradToRad) - Math.PI / 2
                    property bool isMajor: (gradValue % 20 === 0)
                    property bool isHundred: (gradValue % 100 === 0)
                    property real tickLen: isHundred ? 14 : (isMajor ? 9 : 5)
                    property real tickWidth: isHundred ? 2 : 1
                    
                    ShapePath {
                        strokeColor: protractorColor
                        strokeWidth: parent.tickWidth
                        fillColor: "transparent"
                        
                        PathMove {
                            x: protractorItem.cx + (protractorItem.radius - parent.tickLen) * Math.cos(parent.angleRad)
                            y: protractorItem.cy + (protractorItem.radius - parent.tickLen) * Math.sin(parent.angleRad)
                        }
                        PathLine {
                            x: protractorItem.cx + protractorItem.radius * Math.cos(parent.angleRad)
                            y: protractorItem.cy + protractorItem.radius * Math.sin(parent.angleRad)
                        }
                    }
                }
            }
            
            // Labels (every 20 grads)
            Repeater {
                model: 20  // 400 / 20 = 20 labels
                
                Text {
                    property int gradValue: index * 20
                    property real angleRad: (gradValue * gradToRad) + (protractorRotationGrads * gradToRad) - Math.PI / 2
                    property real labelR: protractorItem.radius - 22
                    
                    x: protractorItem.cx + labelR * Math.cos(angleRad) - width / 2
                    y: protractorItem.cy + labelR * Math.sin(angleRad) - height / 2
                    
                    text: gradValue.toString()
                    color: protractorColor
                    font.bold: (gradValue % 100 === 0)
                    font.pixelSize: (gradValue % 100 === 0) ? 12 : 10
                    
                    // Ensure text is readable
                    style: Text.Outline
                    styleColor: "#FFFFFF"
                }
            }
            
            // Center crosshair
            Shape {
                anchors.fill: parent
                vendorExtensionsEnabled: true
                
                ShapePath {
                    strokeColor: protractorColor
                    strokeWidth: 2
                    fillColor: "transparent"
                    
                    PathMove { x: protractorItem.cx - 8; y: protractorItem.cy }
                    PathLine { x: protractorItem.cx + 8; y: protractorItem.cy }
                    PathMove { x: protractorItem.cx; y: protractorItem.cy - 8 }
                    PathLine { x: protractorItem.cx; y: protractorItem.cy + 8 }
                }
            }
            
            // Center dot
            Rectangle {
                x: protractorItem.cx - 4
                y: protractorItem.cy - 4
                width: 8
                height: 8
                radius: 4
                color: protractorColor
            }
            
            // Rotation handle
            Rectangle {
                property real handleAngle: (protractorRotationGrads * gradToRad) - Math.PI / 2
                property real hx: protractorItem.cx + protractorItem.radius * Math.cos(handleAngle) - 8
                property real hy: protractorItem.cy + protractorItem.radius * Math.sin(handleAngle) - 8
                
                x: hx
                y: hy
                width: 16
                height: 16
                radius: 8
                color: "#FF3333"
                border.color: "#FFFFFF"
                border.width: 2
            }
        }
        
        // ============================================================
        // DRAG AREA (center of protractor)
        // ============================================================
        
        MouseArea {
            id: dragArea
            x: overlayContainer.screenCenter.x - 25
            y: overlayContainer.screenCenter.y - 25
            width: 50
            height: 50
            enabled: protractorActive
            
            property real dragStartX: 0
            property real dragStartY: 0
            
            onPressed: {
                dragStartX = mouse.x
                dragStartY = mouse.y
            }
            
            onPositionChanged: {
                if (pressed && mapSettings) {
                    var dx = mouse.x - dragStartX
                    var dy = mouse.y - dragStartY
                    
                    var newScreenX = overlayContainer.screenCenter.x + dx
                    var newScreenY = overlayContainer.screenCenter.y + dy
                    
                    var newMapPt = mapSettings.screenToCoordinate(
                        Qt.point(newScreenX, newScreenY)
                    )
                    protractorCenter = { x: newMapPt.x, y: newMapPt.y }
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? protractorColor : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // ROTATION HANDLE
        // ============================================================
        
        MouseArea {
            id: rotateArea
            enabled: protractorActive
            
            property real handleAngle: (protractorRotationGrads * gradToRad) - Math.PI / 2
            property real handleX: overlayContainer.screenCenter.x + overlayContainer.screenRadius * Math.cos(handleAngle) - 12
            property real handleY: overlayContainer.screenCenter.y + overlayContainer.screenRadius * Math.sin(handleAngle) - 12
            
            x: handleX
            y: handleY
            width: 24
            height: 24
            
            property real startAngle: 0
            property real startGrads: 0
            
            onPressed: {
                startAngle = Math.atan2(
                    mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                    mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                )
                startGrads = protractorRotationGrads
            }
            
            onPositionChanged: {
                if (pressed) {
                    var currentAngle = Math.atan2(
                        mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                        mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                    )
                    var angleDiff = currentAngle - startAngle
                    var gradDiff = (angleDiff / (2 * Math.PI)) * 400
                    protractorRotationGrads = (startGrads + gradDiff) % 400
                    if (protractorRotationGrads < 0) protractorRotationGrads += 400
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? "#FF3333" : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // SETTINGS PANEL
        // ============================================================
        
        Rectangle {
            id: settingsPanel
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
            width: 150
            height: 200
            color: Theme.mainBackgroundColor
            border.color: Theme.mainTextColor
            border.width: 1
            radius: 6
            opacity: 0.95
            visible: protractorActive
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 6
                
                Label {
                    text: "Protractor"
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }
                
                Label {
                    text: "Radius: " + Math.round(protractorRadiusMeters) + " m"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 10
                    to: 500
                    value: protractorRadiusMeters
                    onValueChanged: protractorRadiusMeters = value
                    Layout.fillWidth: true
                }
                
                Label {
                    text: "Rotation: " + Math.round(protractorRotationGrads) + " g"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 0
                    to: 400
                    value: protractorRotationGrads
                    onValueChanged: protractorRotationGrads = value
                    Layout.fillWidth: true
                }
                
                Button {
                    text: "Reset"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = 0
                        if (mapSettings) {
                            let c = mapSettings.getCenter()
                            protractorCenter = { x: c.x, y: c.y }
                        }
                    }
                }
                
                Button {
                    text: "Snap to 10g"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = Math.round(protractorRotationGrads / 10) * 10
                    }
                }
            }
        }
    }
}