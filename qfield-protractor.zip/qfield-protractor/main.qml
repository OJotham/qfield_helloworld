import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield
import org.qgis
import Theme

Item {
    id: pluginRoot
    
    // ============================================================
    // CORE REFERENCES
    // ============================================================
    
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var mapSettings: mapCanvas ? mapCanvas.mapSettings : null
    
    // ============================================================
    // PROTRACTOR STATE
    // ============================================================
    
    // Center in map coordinates (simple JS object with x,y)
    property var protractorCenter: null
    property real protractorRadiusMeters: 500.0
    property real protractorRotationGrads: 0.0
    property bool protractorActive: false
    
    // Visuals
    property color protractorColor: "#FF6B35"
    property real protractorOpacity: 0.65
    
    // Constants
    readonly property int gradsFullCircle: 400
    readonly property real gradToRad: 2.0 * Math.PI / 400.0
    
    // ============================================================
    // INITIALIZATION
    // ============================================================
    
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(toggleButton)
        
        if (mapSettings) {
            let center = mapSettings.center
            protractorCenter = { x: center.x, y: center.y }
        }
    }
    
    // ============================================================
    // TOOLBAR BUTTON
    // ============================================================
    
    ToolButton {
        id: toggleButton
        contentItem: Text {
            text: "📐"
            font.pixelSize: 20
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            color: protractorActive ? protractorColor : Theme.mainTextColor
        }
        
        onClicked: {
            protractorActive = !protractorActive
            if (protractorActive && !protractorCenter && mapSettings) {
                let c = mapSettings.center
                protractorCenter = { x: c.x, y: c.y }
            }
            mainWindow.displayToast(protractorActive ? "Protractor ON" : "Protractor OFF")
        }
    }
    
    // ============================================================
    // OVERLAY CONTAINER
    // ============================================================
    
    Rectangle {
        id: overlayContainer
        anchors.fill: parent
        color: "transparent"
        visible: protractorActive && mapSettings !== null
        opacity: protractorOpacity
        
        // Block map touches when interacting with protractor controls
        // (We use smaller MouseAreas for precise control instead)
        
        // ============================================================
        // SCREEN POSITION & SIZE CALCULATIONS
        // ============================================================
        
        // Convert map center to screen pixels
        property point screenCenter: {
            if (!mapSettings || !protractorCenter) {
                return Qt.point(-9999, -9999)
            }
            let pt = mapSettings.coordinateToScreen(
                Qt.point(protractorCenter.x, protractorCenter.y)
            )
            return Qt.point(pt.x, pt.y)
        }
        
        // Calculate screen radius in pixels
        // We use a two-point distance method for accuracy across CRS types
        property real screenRadius: {
            if (!mapSettings || !protractorCenter) return 100
            
            // Method: compute a point 'radiusMeters' east of center in map CRS,
            // then convert both to screen and measure pixel distance.
            // This handles degrees, feet, meters correctly.
            
            let mpp = mapSettings.mapUnitsPerPoint
            if (mpp <= 0) return 100
            
            // Approximate conversion: if CRS is in degrees, we need special handling
            // For simplicity, use a scaling approach based on output DPI
            let dpi = mapSettings.outputDpi || 96
            let scale = mapSettings.scale || 1
            
            // Basic formula: meters * (dpi / 0.0254) / scale = pixels
            // 0.0254 meters = 1 inch, dpi = dots per inch
            let pixelsPerMeter = dpi / 0.0254 / scale
            
            // But this only works for projected CRS in meters.
            // For geographic CRS (degrees), mapUnitsPerPoint is in degrees.
            // We'll use a fallback: assume 1 degree ≈ 111,000 meters at equator
            let centerPt = mapSettings.center
            let isGeographic = Math.abs(centerPt.x) <= 180 && Math.abs(centerPt.y) <= 90
            
            if (isGeographic && mpp > 0.0001) {
                // Geographic CRS: mapUnitsPerPoint is in degrees
                // 1 degree latitude ≈ 111,000 meters
                let metersPerDegree = 111000 * Math.cos(centerPt.y * Math.PI / 180)
                let metersPerPixel = mpp * metersPerDegree
                if (metersPerPixel > 0) {
                    return protractorRadiusMeters / metersPerPixel
                }
            }
            
            // Projected CRS (meters, feet, etc.)
            // If units are feet, convert to meters first
            // This is approximate but works for most cases
            let unitsPerMeter = 1.0  // Assume meters
            let projCrs = mapSettings.destinationCrs
            if (projCrs) {
                let units = projCrs.mapUnits  // 0=unknown, 1=meters, 2=feet, 3=degrees, etc.
                if (units === 2) unitsPerMeter = 0.3048  // feet
                if (units === 3) unitsPerMeter = 111000  // degrees (rough)
            }
            
            let metersPerPixel = mpp / unitsPerMeter
            if (metersPerPixel > 0) {
                return protractorRadiusMeters / metersPerPixel
            }
            
            return 100  // Fallback
        }
        
        // ============================================================
        // HIGH-DPI AWARE PROTRACTOR CANVAS
        // ============================================================
        
        // The Canvas must be sized in device pixels, not logical pixels
        // We use an inner canvas with explicit pixel scaling
        
        Item {
            id: protractorWrapper
            x: overlayContainer.screenCenter.x - logicalSize / 2
            y: overlayContainer.screenCenter.y - logicalSize / 2
            width: logicalSize
            height: logicalSize
            
            property real logicalSize: Math.max(overlayContainer.screenRadius * 2 + 80, 0)
            property real dpr: Screen.devicePixelRatio || 1.0
            
            visible: overlayContainer.screenCenter.x > -1000 && overlayContainer.screenRadius > 10
            
            Canvas {
                id: protractorCanvas
                anchors.fill: parent
                // CRITICAL: Set canvas pixel size to device pixels, not logical pixels
                width: parent.width * parent.dpr
                height: parent.height * parent.dpr
                // Scale the context so drawing uses logical coordinates
                scale: parent.dpr
                
                antialiasing: true
                renderTarget: Canvas.FramebufferObject
                
                onPaint: {
                    var ctx = getContext("2d")
                    
                    // Clear using logical dimensions
                    ctx.clearRect(0, 0, protractorWrapper.logicalSize, protractorWrapper.logicalSize)
                    
                    var cx = protractorWrapper.logicalSize / 2
                    var cy = protractorWrapper.logicalSize / 2
                    var r = overlayContainer.screenRadius
                    
                    if (r <= 0) return
                    
                    // -- Outer circle --
                    ctx.beginPath()
                    ctx.arc(cx, cy, r, 0, 2 * Math.PI)
                    ctx.strokeStyle = protractorColor
                    ctx.lineWidth = 2.5
                    ctx.stroke()
                    
                    // -- Semitransparent fill --
                    ctx.fillStyle = protractorColor.replace("#", "#22")
                    ctx.fill()
                    
                    // -- Inner rim --
                    ctx.beginPath()
                    ctx.arc(cx, cy, r - 4, 0, 2 * Math.PI)
                    ctx.strokeStyle = protractorColor.replace("#", "#55")
                    ctx.lineWidth = 1
                    ctx.stroke()
                    
                    // -- Graduation marks (every 5 grads) --
                    ctx.textAlign = "center"
                    ctx.textBaseline = "middle"
                    
                    for (var g = 0; g < 400; g += 5) {
                        var angleRad = (g * gradToRad) + (protractorRotationGrads * gradToRad) - Math.PI / 2
                        
                        var isMajor = (g % 20 === 0)
                        var isHundred = (g % 100 === 0)
                        var tickLen = isHundred ? 14 : (isMajor ? 9 : 5)
                        
                        var tx1 = cx + (r - tickLen) * Math.cos(angleRad)
                        var ty1 = cy + (r - tickLen) * Math.sin(angleRad)
                        var tx2 = cx + r * Math.cos(angleRad)
                        var ty2 = cy + r * Math.sin(angleRad)
                        
                        ctx.beginPath()
                        ctx.moveTo(tx1, ty1)
                        ctx.lineTo(tx2, ty2)
                        ctx.strokeStyle = protractorColor
                        ctx.lineWidth = isHundred ? 2 : 1
                        ctx.stroke()
                        
                        // Labels every 20 grads
                        if (isMajor) {
                            var labelR = r - 22
                            var lx = cx + labelR * Math.cos(angleRad)
                            var ly = cy + labelR * Math.sin(angleRad)
                            ctx.fillStyle = protractorColor
                            ctx.font = isHundred ? "bold 12px sans-serif" : "10px sans-serif"
                            ctx.fillText(g.toString(), lx, ly)
                        }
                    }
                    
                    // -- Center crosshair --
                    ctx.beginPath()
                    ctx.moveTo(cx - 8, cy)
                    ctx.lineTo(cx + 8, cy)
                    ctx.moveTo(cx, cy - 8)
                    ctx.lineTo(cx, cy + 8)
                    ctx.strokeStyle = protractorColor
                    ctx.lineWidth = 2
                    ctx.stroke()
                    
                    // -- Center dot --
                    ctx.beginPath()
                    ctx.arc(cx, cy, 3, 0, 2 * Math.PI)
                    ctx.fillStyle = protractorColor
                    ctx.fill()
                    
                    // -- Rotation handle at 0 grad (top) --
                    var handleAngle = (protractorRotationGrads * gradToRad) - Math.PI / 2
                    var hx = cx + r * Math.cos(handleAngle)
                    var hy = cy + r * Math.sin(handleAngle)
                    
                    ctx.beginPath()
                    ctx.arc(hx, hy, 7, 0, 2 * Math.PI)
                    ctx.fillStyle = "#FF3333"
                    ctx.fill()
                    ctx.strokeStyle = "#FFFFFF"
                    ctx.lineWidth = 2
                    ctx.stroke()
                }
            }
        }
        
        // Force redraw on map changes
        Timer {
            interval: 100
            running: protractorActive && mapSettings !== null
            repeat: true
            onTriggered: protractorCanvas.requestPaint()
        }
        
        // ============================================================
        // DRAG AREA (center of protractor)
        // ============================================================
        
        MouseArea {
            id: dragArea
            x: overlayContainer.screenCenter.x - 25
            y: overlayContainer.screenCenter.y - 25
            width: 50
            height: 50
            enabled: protractorActive
            
            property real dragStartX: 0
            property real dragStartY: 0
            
            onPressed: {
                dragStartX = mouse.x
                dragStartY = mouse.y
            }
            
            onPositionChanged: {
                if (pressed && mapSettings) {
                    var dx = mouse.x - dragStartX
                    var dy = mouse.y - dragStartY
                    
                    var newScreenX = overlayContainer.screenCenter.x + dx
                    var newScreenY = overlayContainer.screenCenter.y + dy
                    
                    var newMapPt = mapSettings.screenToCoordinate(
                        Qt.point(newScreenX, newScreenY)
                    )
                    protractorCenter = { x: newMapPt.x, y: newMapPt.y }
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? protractorColor : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // ROTATION HANDLE AREA
        // ============================================================
        
        MouseArea {
            id: rotateArea
            enabled: protractorActive
            
            property real handleAngle: (protractorRotationGrads * gradToRad) - Math.PI / 2
            property real handleX: overlayContainer.screenCenter.x + overlayContainer.screenRadius * Math.cos(handleAngle) - 12
            property real handleY: overlayContainer.screenCenter.y + overlayContainer.screenRadius * Math.sin(handleAngle) - 12
            
            x: handleX
            y: handleY
            width: 24
            height: 24
            
            property real startAngle: 0
            property real startGrads: 0
            
            onPressed: {
                startAngle = Math.atan2(
                    mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                    mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                )
                startGrads = protractorRotationGrads
            }
            
            onPositionChanged: {
                if (pressed) {
                    var currentAngle = Math.atan2(
                        mouse.y + rotateArea.y - overlayContainer.screenCenter.y,
                        mouse.x + rotateArea.x - overlayContainer.screenCenter.x
                    )
                    var angleDiff = currentAngle - startAngle
                    var gradDiff = (angleDiff / (2 * Math.PI)) * 400
                    protractorRotationGrads = (startGrads + gradDiff) % 400
                    if (protractorRotationGrads < 0) protractorRotationGrads += 400
                }
            }
            
            Rectangle {
                anchors.fill: parent
                color: "transparent"
                border.color: parent.pressed ? "#FF3333" : "transparent"
                border.width: 2
                radius: width / 2
            }
        }
        
        // ============================================================
        // SETTINGS PANEL
        // ============================================================
        
        Rectangle {
            id: settingsPanel
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 10
            width: 150
            height: 200
            color: Theme.mainBackgroundColor
            border.color: Theme.mainTextColor
            border.width: 1
            radius: 6
            opacity: 0.95
            visible: protractorActive
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 6
                
                Label {
                    text: "Protractor"
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }
                
                Label {
                    text: "Radius: " + Math.round(protractorRadiusMeters) + " m"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 10
                    to: 500
                    value: protractorRadiusMeters
                    onValueChanged: protractorRadiusMeters = value
                    Layout.fillWidth: true
                }
                
                Label {
                    text: "Rotation: " + Math.round(protractorRotationGrads) + " g"
                    font.pixelSize: 11
                }
                
                Slider {
                    from: 0
                    to: 400
                    value: protractorRotationGrads
                    onValueChanged: protractorRotationGrads = value
                    Layout.fillWidth: true
                }
                
                Button {
                    text: "Reset"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = 0
                        if (mapSettings) {
                            let c = mapSettings.center
                            protractorCenter = { x: c.x, y: c.y }
                        }
                    }
                }
                
                Button {
                    text: "Snap to 10g"
                    Layout.fillWidth: true
                    onClicked: {
                        protractorRotationGrads = Math.round(protractorRotationGrads / 10) * 10
                    }
                }
            }
        }
    }
}